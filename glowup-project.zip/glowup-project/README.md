# GlowUp Online — Setup Guide

## 1. Put the project in your server folder
- XAMPP: copy this whole `glowup-project` folder into `C:\xampp\htdocs\`
- Rename the folder if you want a shorter URL, e.g. `htdocs\glowup`

## 2. Create the database
1. Start Apache and MySQL in the XAMPP Control Panel.
2. Open `http://localhost/phpmyadmin`
3. Click **Import** → choose `database.sql` → click **Go**
   - This creates the `glowup_db` database with the `users` and `audit_logs` tables.

## 3. Check your DB credentials
Open `config/db.php` — the defaults (`root`, no password, `localhost`) match a
standard XAMPP install, so usually you don't need to change anything.

## 4. Run it
Visit `http://localhost/glowup-project/index.php` in your browser.

## How the pieces fit together
- `includes/header.php` / `includes/footer.php` — shared layout, included on every page
- `config/db.php` — one database connection + session_start(), reused everywhere
- `index.php`, `about.php` — public pages
- `register.php` — validates input, hashes the password, saves to `users`, logs to `audit_logs`
- `login.php` — checks credentials, starts `$_SESSION`, logs to `audit_logs`
- `logout.php` — logs the logout, then destroys the session
- `verify.php` — optional: marks a user as verified using the demo link shown after registration
  (no real email is sent — that's outside the scope of this project)

## Notes for your defense
- Passwords are stored using `password_hash()` / `password_verify()` — never plain text.
- All SQL queries use prepared statements (`mysqli_prepare` + `bind_param`) to prevent SQL injection.
- `audit_logs` records every register / login / logout with a timestamp.
