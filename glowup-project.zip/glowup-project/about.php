<?php
require_once 'config/db.php';
include 'includes/header.php';
?>

<h1>About Us</h1>
<p>
  GlowUp Online is a student project created for our IT coursework. We're building
  a simple e-commerce style website to practice PHP, MySQL, and basic web security
  concepts such as input validation, password hashing, and session handling.
</p>

<p>
  This project covers two main parts:
</p>
<ul>
  <li>A shared website layout (header, footer, navigation) used across all pages.</li>
  <li>A buyer registration and login system with validation and audit logging.</li>
</ul>

<?php include 'includes/footer.php'; ?>
