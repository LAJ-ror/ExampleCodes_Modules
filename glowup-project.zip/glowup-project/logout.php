<?php
require_once 'config/db.php';

if (isset($_SESSION['user_id'])) {
    // Record in audit_logs before the session is wiped
    $log = mysqli_prepare($conn, "INSERT INTO audit_logs (user_id, action) VALUES (?, ?)");
    $action = "logout";
    mysqli_stmt_bind_param($log, "is", $_SESSION['user_id'], $action);
    mysqli_stmt_execute($log);
    mysqli_stmt_close($log);
}

// Destroy the session
$_SESSION = [];
session_destroy();

header("Location: login.php");
exit();
