<?php
require_once 'config/db.php';

$errors = [];
$email = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $errors[] = "Email and password are required.";
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "SELECT id, full_name, password FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($user && password_verify($password, $user['password'])) {
            // Start the logged-in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];

            // Record in audit_logs
            $log = mysqli_prepare($conn, "INSERT INTO audit_logs (user_id, action) VALUES (?, ?)");
            $action = "login";
            mysqli_stmt_bind_param($log, "is", $user['id'], $action);
            mysqli_stmt_execute($log);
            mysqli_stmt_close($log);

            header("Location: index.php");
            exit();
        } else {
            $errors[] = "Invalid email or password.";
        }
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card form-card">
      <div class="card-body p-4">
        <h2 class="text-center mb-4">Login</h2>

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0">
              <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control">
          </div>
          <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>

        <p class="text-center mt-3 mb-0">Don't have an account? <a href="register.php">Register here</a></p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
