<?php
require_once 'config/db.php';

$errors = [];
$success = "";
$full_name = "";
$email = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // ---- Validation ----
    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $errors[] = "All fields are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long.";
    }

    // Check if email is already used
    if (empty($errors)) {
        $check = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($check, "s", $email);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if (mysqli_stmt_num_rows($check) > 0) {
            $errors[] = "That email is already registered.";
        }
        mysqli_stmt_close($check);
    }

    // Save new user
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verify_token = bin2hex(random_bytes(16));

        $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, email, password, verify_token) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $full_name, $email, $hashed_password, $verify_token);

        if (mysqli_stmt_execute($stmt)) {
            $user_id = mysqli_insert_id($conn);

            // Record in audit_logs
            $log = mysqli_prepare($conn, "INSERT INTO audit_logs (user_id, action) VALUES (?, ?)");
            $action = "register";
            mysqli_stmt_bind_param($log, "is", $user_id, $action);
            mysqli_stmt_execute($log);
            mysqli_stmt_close($log);

            $success = "Registration successful! You may now <a href='login.php'>login</a>.";
            // No real email is sent in this school project — this link simulates
            // the verification email so you can demo it during your defense.
            $success .= "<br><small>Demo verification link: "
                      . "<a href='verify.php?token=" . htmlspecialchars($verify_token) . "'>"
                      . "verify.php?token=" . htmlspecialchars($verify_token) . "</a></small>";

            $full_name = "";
            $email = "";
        } else {
            $errors[] = "Something went wrong. Please try again.";
        }
        mysqli_stmt_close($stmt);
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card form-card">
      <div class="card-body p-4">
        <h2 class="text-center mb-4">Create an Account</h2>

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0">
              <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <?php if ($success): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" action="register.php">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($full_name); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control">
          </div>
          <button type="submit" class="btn btn-primary w-100">Register</button>
        </form>

        <p class="text-center mt-3 mb-0">Already have an account? <a href="login.php">Login here</a></p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
