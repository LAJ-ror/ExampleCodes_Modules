<?php
require_once 'config/db.php';

$message = "";

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE verify_token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if ($user) {
        $update = mysqli_prepare($conn, "UPDATE users SET is_verified = 1, verify_token = NULL WHERE id = ?");
        mysqli_stmt_bind_param($update, "i", $user['id']);
        mysqli_stmt_execute($update);
        mysqli_stmt_close($update);

        $message = "Your email has been verified! You can now log in.";
    } else {
        $message = "Invalid or expired verification link.";
    }
} else {
    $message = "No verification token provided.";
}

include 'includes/header.php';
?>

<div class="text-center">
  <h2>Email Verification</h2>
  <p><?php echo htmlspecialchars($message); ?></p>
  <a href="login.php" class="btn btn-primary">Go to Login</a>
</div>

<?php include 'includes/footer.php'; ?>
