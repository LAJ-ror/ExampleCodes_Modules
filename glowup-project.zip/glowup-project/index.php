<?php
require_once 'config/db.php';
include 'includes/header.php';
?>

<div class="hero text-center mb-5">
  <h1>Welcome to GlowUp Online</h1>
  <p class="lead">Premium bags and accessories, crafted with style.</p>

  <?php if (!isset($_SESSION['user_id'])): ?>
    <a href="register.php" class="btn btn-primary me-2">Get Started</a>
    <a href="login.php" class="btn btn-outline-secondary">Login</a>
  <?php else: ?>
    <p>Welcome back, <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong>!</p>
  <?php endif; ?>
</div>

<div class="row g-4">
  <div class="col-md-4">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title">Quality Materials</h5>
        <p class="card-text">Every piece is made with premium leather and careful craftsmanship.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title">Timeless Design</h5>
        <p class="card-text">Classic silhouettes with a modern, earthy color palette.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title">Made to Last</h5>
        <p class="card-text">Built for everyday use without compromising on style.</p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
