<?php
// Start session once, no matter which page includes this file first
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Database settings (edit to match your phpMyAdmin/XAMPP setup) ----
$host   = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "glowup_db";

$conn = mysqli_connect($host, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
